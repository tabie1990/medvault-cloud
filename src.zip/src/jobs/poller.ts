import { prisma } from '../db/prisma.js';
import { dispatchPendingNotifications, queueNotification } from '../services/notification.service.js';
import { checkPaymentStatus } from '../services/payment.service.js';
import { createTelemedicineSession, createRoomForSession } from '../services/telemedicine.service.js';
import { expireStaleInstantRequests } from '../services/teleconsult-request.service.js';
import { logError } from '../services/error-log.service.js';
import crypto from 'crypto';

/**
 * Replaces the separate sync-worker / appointment-worker apps (and Azure
 * Service Bus) with in-process polling. At the traffic level a handful of
 * hospitals actually generate, a distributed message broker solves a
 * scaling problem this system doesn't have yet. Each function below is
 * still isolated enough to lift into a real worker later if you ever
 * outgrow a single process — but don't build that until you have the
 * traffic to justify it.
 */

const INTERVAL_MS = 10_000;

/**
 * Builds the identity payload sent alongside a booking. If this hospital
 * already has a local record for this global patient (they've been seen
 * here before, possibly at a different hospital originally), that's an
 * exact, known fact — not a guess — so it's surfaced separately from the
 * phone/name/dob details used for fuzzy matching on a genuinely new patient.
 */
async function buildPatientIdentity(globalPatientId: string | null) {
  if (!globalPatientId) return null;
  const patient = await prisma.globalPatient.findUnique({ where: { globalPatientId } });
  if (!patient) return null;
  return {
    phone: patient.primaryPhone,
    fullName: patient.fullName,
    dob: patient.dob,
    sex: patient.sex
  };
}

async function findExistingLocalPatient(globalPatientId: string | null, hospitalId: string | null) {
  if (!globalPatientId || !hospitalId) return null;
  const map = await prisma.patientIdentityMap.findFirst({
    where: { globalPatientId, hospitalId }
  });
  if (!map) return null;
  return { localPatientId: map.localPatientId, hospitalCode: map.hospitalCode };
}

async function fanOutNewAppointments() {
  const pending = await prisma.appointment.findMany({
    where: {
      status: 'pending',
      hospitalId: { not: null },
      syncedToHospitalAt: null
    },
    take: 25
  });

  for (const appt of pending) {
    if (!appt.hospitalId) continue;

    const patientIdentity = await buildPatientIdentity(appt.globalPatientId);
    const existingLocalPatient = await findExistingLocalPatient(appt.globalPatientId, appt.hospitalId);

    await prisma.syncEvent.create({
      data: {
        hospitalId: appt.hospitalId,
        installationId: '00000000-0000-0000-0000-000000000000',
        eventId: crypto.randomUUID(),
        eventType: 'appointment.created',
        entityType: 'appointment',
        entityId: appt.id,
        globalPatientId: appt.globalPatientId,
        payload: { ...appt, patientIdentity, existingLocalPatient } as any,
        direction: 'cloud_to_hospital',
        status: 'pending'
      }
    });
    await prisma.appointment.update({
      where: { id: appt.id },
      data: { syncedToHospitalAt: new Date() }
    });
  }
}

async function fanOutLabOrderEvents() {
  const orders = await prisma.labOrder.findMany({
    where: {
      hospitalId: { not: null },
      OR: [
        { status: 'requested', lastSyncedStatus: null },
        { status: 'completed', NOT: { lastSyncedStatus: 'completed' } }
      ]
    },
    take: 25
  });

  for (const order of orders) {
    if (!order.hospitalId) continue;

    const patientIdentity = await buildPatientIdentity(order.globalPatientId);
    const existingLocalPatient = await findExistingLocalPatient(order.globalPatientId, order.hospitalId);

    await prisma.syncEvent.create({
      data: {
        hospitalId: order.hospitalId,
        installationId: '00000000-0000-0000-0000-000000000000',
        eventId: crypto.randomUUID(),
        eventType: order.status === 'completed' ? 'lab_order.completed' : 'lab_order.created',
        entityType: 'lab_order',
        entityId: order.id,
        globalPatientId: order.globalPatientId,
        payload: { ...order, patientIdentity, existingLocalPatient } as any,
        direction: 'cloud_to_hospital',
        status: 'pending'
      }
    });
    await prisma.labOrder.update({
      where: { id: order.id },
      data: { lastSyncedStatus: order.status }
    });
  }
}

const ACK_TIMEOUT_MINUTES = 30;

// hospital_to_cloud events: the cloud already did whatever processing it
// needs synchronously in POST /sync/push (e.g. creating the GlobalPatient),
// so 'queued' here just means "logged" — safe to finalize automatically.
async function finalizeHospitalPushedEvents() {
  const queued = await prisma.syncEvent.findMany({
    where: { status: 'queued', direction: 'hospital_to_cloud' },
    take: 50
  });
  for (const evt of queued) {
    await prisma.syncEvent.update({
      where: { id: evt.id },
      data: { status: 'processed', processedAt: new Date() }
    });
  }
}

// cloud_to_hospital events: 'queued' means "delivered via GET /sync/pull,
// awaiting the hospital's POST /sync/ack". If a hospital pulls an event but
// then loses connectivity before it can apply it locally and ack, that
// event must NOT be silently marked processed — it needs to go back to
// 'pending' so the next pull redelivers it.
async function requeueStaleUnackedEvents() {
  const cutoff = new Date(Date.now() - ACK_TIMEOUT_MINUTES * 60 * 1000);
  await prisma.syncEvent.updateMany({
    where: { status: 'queued', direction: 'cloud_to_hospital', queuedAt: { lt: cutoff } },
    data: { status: 'pending' }
  });
}

/**
 * Closes the actual gap found via real testing: nothing previously
 * re-checked Campay after the initial payment request, so a payment that
 * genuinely cleared could sit showing "pending" forever unless someone
 * happened to ask again. This polls every pending teleconsult payment,
 * and the moment one clears: creates the telemedicine session and room
 * (same path the doctor's own "Start session" button uses — this isn't a
 * separate room-creation mechanism, just triggering the existing one
 * automatically instead of waiting for a manual click), then notifies
 * both patient and doctor with the link.
 */
async function checkPendingTeleconsultPayments() {
  const pending = await prisma.appointment.findMany({
    where: { appointmentType: 'teleconsult', paymentStatus: 'pending', paymentReference: { not: null } },
    take: 20
  });

  for (const appt of pending) {
    const result = await checkPaymentStatus(appt.id);
    if (result.status !== 'paid') continue; // still pending or failed — nothing to do yet

    if (!appt.doctorId) continue; // no doctor assigned yet — can't create a session without one

    const session = await createTelemedicineSession(appt.id, appt.doctorId);
    const withRoom = await createRoomForSession(session.id);
    if (!withRoom.roomUrl) continue;

    if (appt.globalPatientId) {
      await queueNotification({
        channel: 'whatsapp',
        recipientType: 'patient',
        recipientRef: appt.globalPatientId,
        templateType: 'teleconsult_payment_confirmed',
        payload: { params: [appt.appointmentRef, withRoom.roomUrl] }
      });
    }
    await queueNotification({
      channel: 'whatsapp',
      recipientType: 'doctor',
      recipientRef: appt.doctorId,
      templateType: 'teleconsult_payment_confirmed',
      payload: { params: [appt.appointmentRef, withRoom.roomUrl] }
    });
  }
}

/**
 * Reminds both patient and doctor 30 minutes before a paid teleconsult.
 * Checked every cycle but only ever sends once per appointment, guarded
 * by reminderSentAt — a 10-second poll interval would otherwise fire
 * this dozens of times for the same appointment inside that half hour.
 */
async function sendUpcomingAppointmentReminders() {
  const now = new Date();
  const windowStart = new Date(now.getTime() + 25 * 60 * 1000); // 25-35 min out
  const windowEnd = new Date(now.getTime() + 35 * 60 * 1000);

  const upcoming = await prisma.appointment.findMany({
    where: {
      appointmentType: 'teleconsult',
      paymentStatus: 'paid',
      status: { in: ['pending', 'confirmed'] },
      requestedDate: { gte: windowStart, lte: windowEnd },
      reminderSentAt: null
    },
    take: 20
  });

  for (const appt of upcoming) {
    if (!appt.doctorId) continue;
    const session = await prisma.telemedicineSession.findUnique({ where: { appointmentId: appt.id } });
    const roomUrl = session?.roomUrl;
    if (!roomUrl) continue; // no room yet — nothing useful to remind about

    if (appt.globalPatientId) {
      await queueNotification({
        channel: 'whatsapp',
        recipientType: 'patient',
        recipientRef: appt.globalPatientId,
        templateType: 'teleconsult_reminder_30min',
        payload: { params: [appt.appointmentRef, roomUrl] }
      });
    }
    await queueNotification({
      channel: 'whatsapp',
      recipientType: 'doctor',
      recipientRef: appt.doctorId,
      templateType: 'teleconsult_reminder_30min',
      payload: { params: [appt.appointmentRef, roomUrl] }
    });

    await prisma.appointment.update({ where: { id: appt.id }, data: { reminderSentAt: now } });
  }
}

/**
 * Flags any VaccinationRecord whose scheduledDate has passed and is
 * still sitting at 'due' as 'overdue', and sends one reminder to every
 * guardian linked to that child — guarded by reminderSentAt, same
 * pattern as the teleconsult reminder poller, so it never repeats.
 */
async function checkOverdueVaccinations() {
  const now = new Date();
  const overdue = await prisma.vaccinationRecord.findMany({
    where: { status: 'due', scheduledDate: { lt: now }, reminderSentAt: null },
    include: { scheduleItem: true },
    take: 50
  });

  // Grouped by child first — a child with several newly-overdue doses at
  // once gets ONE combined reminder, not a separate message per dose.
  // The earlier version fired one WhatsApp message per record here,
  // which meant a child overdue on 11 doses sent 11 back-to-back
  // messages to the guardian — a real, confirmed bad experience, not a
  // hypothetical one.
  const byChild = new Map<string, typeof overdue>();
  for (const record of overdue) {
    const list = byChild.get(record.childPatientId) ?? [];
    list.push(record);
    byChild.set(record.childPatientId, list);
  }

  for (const [childPatientId, records] of byChild) {
    await prisma.vaccinationRecord.updateMany({
      where: { id: { in: records.map((r: any) => r.id) } },
      data: { status: 'overdue' }
    });

    const guardianLinks = await prisma.guardianLink.findMany({ where: { childPatientId } });
    const child = await prisma.globalPatient.findUnique({ where: { globalPatientId: childPatientId } });
    const vaccineNames = records.map((r: any) => r.scheduleItem.vaccineName).join(', ');

    for (const link of guardianLinks) {
      await queueNotification({
        channel: 'whatsapp',
        recipientType: 'patient',
        recipientRef: link.guardianPatientId,
        templateType: 'vaccination_reminder',
        payload: { params: [child?.fullName ?? 'your child', vaccineNames] }
      }).catch(() => {});
    }

    await prisma.vaccinationRecord.updateMany({
      where: { id: { in: records.map((r: any) => r.id) } },
      data: { reminderSentAt: now }
    });
  }
}

export function startPollers() {
  setInterval(() => fanOutNewAppointments().catch((e) => logError('poller:appointments', e)), INTERVAL_MS);
  setInterval(() => fanOutLabOrderEvents().catch((e) => logError('poller:lab-orders', e)), INTERVAL_MS);
  setInterval(() => finalizeHospitalPushedEvents().catch((e) => logError('poller:sync-events', e)), INTERVAL_MS);
  setInterval(() => requeueStaleUnackedEvents().catch((e) => logError('poller:sync-requeue', e)), INTERVAL_MS);
  setInterval(() => dispatchPendingNotifications().catch((e) => logError('poller:notifications', e)), INTERVAL_MS);
  setInterval(() => checkPendingTeleconsultPayments().catch((e) => logError('poller:payment-check', e)), INTERVAL_MS);
  setInterval(() => sendUpcomingAppointmentReminders().catch((e) => logError('poller:reminders', e)), INTERVAL_MS);
  setInterval(() => checkOverdueVaccinations().catch((e) => logError('poller:vaccinations', e)), INTERVAL_MS);
  // 90-second dispatch window (see teleconsult-request.service.ts) needs
  // to be swept at the same 10s granularity as everything else here, not
  // a slower interval — a stale request sitting 'pending' for even an
  // extra 30-60s past its real expiry is a doctor able to "win" a race
  // the patient has already given up on.
  setInterval(() => expireStaleInstantRequests().catch((e) => logError('poller:instant-consult-expiry', e)), INTERVAL_MS);
  console.log('In-process pollers started (appointments, lab orders, sync events, notifications).');
}
