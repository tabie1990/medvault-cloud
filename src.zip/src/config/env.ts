import dotenv from 'dotenv';
dotenv.config();

function required(name: string, fallbackForDev: string): string {
  const value = process.env[name];
  if (value && value.length > 0) return value;
  if (process.env.NODE_ENV === 'production') {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return fallbackForDev;
}

export const env = {
  nodeEnv: process.env.NODE_ENV ?? 'development',
  port: Number(process.env.PORT ?? 8080),

  jwtSecret: required('JWT_SECRET', 'dev-only-jwt-secret-change-me'),
  secretEncryptionKey: required('SECRET_ENCRYPTION_KEY', 'dev-only-32-char-encryption-key!'),
  hmacClockSkewSeconds: Number(process.env.HMAC_CLOCK_SKEW_SECONDS ?? 300),

  whatsappVerifyToken: process.env.WHATSAPP_VERIFY_TOKEN ?? '',
  whatsappAccessToken: process.env.WHATSAPP_ACCESS_TOKEN ?? '',
  whatsappPhoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID ?? '',

  anthropicApiKey: process.env.ANTHROPIC_API_KEY ?? '',
  openaiApiKey: process.env.OPENAI_API_KEY ?? '',
  // Follow-up copy of every booking, for the early-stage manual
  // follow-up workflow — configurable via env rather than hardcoded, in
  // case it needs to change later.
  internalNotificationEmail: process.env.INTERNAL_NOTIFICATION_EMAIL ?? 'medvault24@gmail.com',
  // 'anthropic' or 'openai' — lets the WhatsApp agent run on either
  // provider for real cost/quality comparison, without needing two
  // separate deployments. Defaults to anthropic (the proven, tested
  // path) if unset or misspelled, rather than silently falling through
  // to something unexpected.
  aiProvider: (process.env.AI_PROVIDER === 'openai' ? 'openai' : 'anthropic') as 'anthropic' | 'openai',

  dailyApiKey: process.env.DAILY_API_KEY ?? '',
  dailySubdomain: process.env.DAILY_SUBDOMAIN ?? '',

  expoAccessToken: process.env.EXPO_ACCESS_TOKEN ?? '',

  // Object storage (Backblaze B2, S3-compatible) — KYC documents/selfies.
  b2Endpoint: process.env.B2_ENDPOINT ?? '',
  b2Region: process.env.B2_REGION ?? 'us-east-005',
  b2Bucket: process.env.B2_BUCKET ?? '',
  b2KeyId: process.env.B2_KEY_ID ?? '',
  b2ApplicationKey: process.env.B2_APPLICATION_KEY ?? '',

  // Transactional email — Namecheap Private Email SMTP
  smtpHost: process.env.SMTP_HOST ?? '',
  smtpPort: Number(process.env.SMTP_PORT ?? 587),
  smtpUser: process.env.SMTP_USER ?? '',
  smtpPassword: process.env.SMTP_PASSWORD ?? '',
  emailFrom: process.env.EMAIL_FROM ?? 'MedVAULT <no-reply@med-vault.com>',

  // Public URL doctors/lab staff use to log in — included in welcome emails
  webAppUrl: process.env.WEB_APP_URL ?? 'https://cloud.med-vault.com',

  // Public URL of this API itself — needed so responses can embed a real,
  // fetchable link back to this server (e.g. doctor photoUrl below).
  // Distinct from webAppUrl (the patient portal's own origin).
  apiBaseUrl: process.env.API_BASE_URL ?? 'https://api.med-vault.com',

  // Campay — same aggregator the HMS's own teleconsult payment flow uses
  // (that implementation is already tested end-to-end with a real phone).
  // Platform-wide here, not per-hospital, since the cloud has exactly one
  // Campay account, unlike each individual HMS installation.
  campayToken: process.env.CAMPAY_TOKEN ?? '',
  campayBaseUrl: process.env.CAMPAY_BASE_URL ?? 'https://demo.campay.net/api/',
  medvaultMomoNumber: process.env.MEDVAULT_MOMO_NUMBER ?? '',
  platformFeePct: Number(process.env.PLATFORM_FEE_PCT ?? 10)
};
