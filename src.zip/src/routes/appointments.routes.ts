import { Router } from 'express';
import { prisma } from '../db/prisma.js';
import { createAppointment, listPendingAppointmentsForHospital } from '../services/appointment.service.js';
import { getSlotsForDate as getHospitalRosterSlotsForDate } from '../services/hospital-roster-availability.service.js';
import { requestPayment, checkPaymentStatus, markPaid, splitPayout } from '../services/payment.service.js';
import { requireAuth, type AuthedRequest } from '../middleware/auth.middleware.js';
import { asyncHandler } from '../middleware/error.middleware.js';

export const appointmentsRouter = Router();

// Shared by request-payment and payment-status — a patient may only act
// on their own appointment, never anyone else's by guessing an ID. A
// doctor may act on any appointment (matches the original Block 3 design,
// where the doctor initiates payment collection during a call).
async function isAuthorizedForAppointmentPayment(appointmentId: string, user: { sub: string; role: string }): Promise<boolean> {
  if (user.role === 'doctor') return true;
  if (user.role === 'patient') {
    const appt = await prisma.appointment.findUnique({ where: { id: appointmentId } });
    return Boolean(appt && appt.globalPatientId === user.sub);
  }
  return false;
}

appointmentsRouter.post(
  '/',
  asyncHandler(async (req, res) => {
    const b = req.body;
    if (!b.appointment_type || !b.source) {
      return res.status(400).json({ success: false, error: 'appointment_type and source are required' });
    }
    // Same discipline as the WhatsApp agent's own tool-execution
    // validation — never let a client book a hospital-roster slot that
    // isn't actually open, whether that client is careless or malicious.
    // A pre-existing gap here (this endpoint had no slot validation at
    // all before) is being closed for the roster case specifically,
    // since that's what's being added right now.
    if (b.appointment_type === 'in_person' && b.hospital_doctor_roster_id) {
      if (!b.requested_date || !b.requested_time) {
        return res.status(400).json({ success: false, error: 'requested_date_and_requested_time_required_when_a_roster_doctor_is_chosen' });
      }
      const realSlots = await getHospitalRosterSlotsForDate(b.hospital_doctor_roster_id, b.requested_date);
      if (!realSlots.includes(b.requested_time)) {
        return res.status(409).json({ success: false, error: 'requested_time_not_available' });
      }
    }
    try {
      const appointment = await createAppointment({
        globalPatientId: b.global_patient_id,
        hospitalId: b.hospital_id,
        doctorId: b.doctor_id,
        hospitalDoctorRosterId: b.hospital_doctor_roster_id,
        appointmentType: b.appointment_type,
        requestedDate: b.requested_date,
        requestedTime: b.requested_time,
        source: b.source,
        channel: b.channel,
        notes: b.notes,
        raw: b
      });
      res.status(201).json({ success: true, appointment });
    } catch (e: any) {
      if (e.message === 'hospital_not_found') {
        return res.status(404).json({ success: false, error: 'hospital_not_found' });
      }
      throw e;
    }
  })
);

appointmentsRouter.get(
  '/hospital/:hospitalId/pending',
  asyncHandler(async (req, res) => {
    const appointments = await listPendingAppointmentsForHospital(req.params.hospitalId);
    res.json({ success: true, appointments });
  })
);

// A doctor's own appointments — needed for their dashboard. Includes any
// linked telemedicine session, since that's how the dashboard knows
// whether a session/room already exists or still needs to be started.
appointmentsRouter.get(
  '/my',
  requireAuth('doctor'),
  asyncHandler(async (req: AuthedRequest, res) => {
    const appointments = await prisma.appointment.findMany({
      where: { doctorId: req.user!.sub },
      include: { telemedicineSession: true },
      orderBy: { createdAt: 'desc' }
    });
    // Appointment.globalPatientId is a loose string, not a formal Prisma
    // relation — a real, pre-existing gap the doctor's own view never
    // actually surfaced (name/DOB/phone), only the raw ID. Batched into
    // one query rather than N+1 lookups per appointment.
    const patientIds = [...new Set(appointments.map((a: any) => a.globalPatientId).filter(Boolean))];
    const patients = await prisma.globalPatient.findMany({ where: { globalPatientId: { in: patientIds as string[] } } });
    const patientsById = new Map<string, any>(patients.map((p: any) => [p.globalPatientId, p]));
    const withPatientDetails = appointments.map((a: any) => ({
      ...a,
      patient: a.globalPatientId
        ? {
            fullName: patientsById.get(a.globalPatientId)?.fullName ?? null,
            dob: patientsById.get(a.globalPatientId)?.dob ?? null,
            phone: patientsById.get(a.globalPatientId)?.primaryPhone ?? null
          }
        : null
    }));
    res.json({ success: true, appointments: withPatientDetails });
  })
);

// A doctor marking their own appointment complete — separate from
// paymentStatus/telemedicineSession, since "the consultation actually
// happened" is a distinct fact a doctor states themselves, not something
// derivable from payment or room state alone.
appointmentsRouter.patch(
  '/:id/complete',
  requireAuth('doctor'),
  asyncHandler(async (req: AuthedRequest, res) => {
    const appt = await prisma.appointment.findUnique({ where: { id: req.params.id } });
    if (!appt) return res.status(404).json({ success: false, error: 'appointment_not_found' });
    if (appt.doctorId !== req.user!.sub) return res.status(403).json({ success: false, error: 'not_your_appointment' });
    const updated = await prisma.appointment.update({ where: { id: req.params.id }, data: { status: 'completed' } });
    res.json({ success: true, appointment: updated });
  })
);

const knownPaymentErrors: Record<string, number> = {
  appointment_not_found: 404,
  invalid_cameroon_phone: 400,
  campay_not_configured: 400,
  campay_returned_non_json_response: 502,
  campay_request_timed_out: 504,
  patient_has_not_paid_yet: 402,
  no_momo_number_found_for_doctor_or_hospital: 400,
  provider_payout_transfer_failed: 500
};

function handlePaymentError(e: any, res: any) {
  const status = knownPaymentErrors[e.message] ?? e.status ?? 500;
  res.status(status).json({
    success: false,
    error: e.message,
    ...(e.raw ? { raw: e.raw } : {}),
    ...(e.rawBody ? { raw_body_preview: e.rawBody } : {})
  });
}

appointmentsRouter.post(
  '/:id/request-payment',
  requireAuth('doctor', 'patient'),
  asyncHandler(async (req: AuthedRequest, res) => {
    if (!(await isAuthorizedForAppointmentPayment(req.params.id, req.user!))) {
      return res.status(403).json({ success: false, error: 'not_authorized_for_this_appointment' });
    }
    const { phone, amount } = req.body;
    if (!phone || !amount) return res.status(400).json({ success: false, error: 'phone and amount are both required' });
    try {
      const data = await requestPayment(req.params.id, phone, Number(amount));
      res.json({ success: true, ...data });
    } catch (e: any) {
      handlePaymentError(e, res);
    }
  })
);

appointmentsRouter.get(
  '/:id/payment-status',
  requireAuth('doctor', 'patient'),
  asyncHandler(async (req: AuthedRequest, res) => {
    if (!(await isAuthorizedForAppointmentPayment(req.params.id, req.user!))) {
      return res.status(403).json({ success: false, error: 'not_authorized_for_this_appointment' });
    }
    try {
      const data = await checkPaymentStatus(req.params.id);
      res.json({ success: true, ...data });
    } catch (e: any) {
      handlePaymentError(e, res);
    }
  })
);

appointmentsRouter.post(
  '/:id/mark-paid',
  requireAuth('doctor'),
  asyncHandler(async (req, res) => {
    const { amount } = req.body;
    if (!amount) return res.status(400).json({ success: false, error: 'amount is required' });
    const appointment = await markPaid(req.params.id, Number(amount));
    res.json({ success: true, appointment });
  })
);

appointmentsRouter.post(
  '/:id/split-payout',
  requireAuth('doctor'),
  asyncHandler(async (req, res) => {
    try {
      const result = await splitPayout(req.params.id);
      res.json({ success: true, ...result });
    } catch (e: any) {
      handlePaymentError(e, res);
    }
  })
);
