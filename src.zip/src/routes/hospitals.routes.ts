import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { prisma } from '../db/prisma.js';
import { encryptSecret } from '../services/crypto.service.js';
import { findHospitalsNear } from '../services/hospital-search.service.js';
import { getSlotsForNextDays as getHospitalRosterSlotsForNextDays } from '../services/hospital-roster-availability.service.js';
import { asyncHandler } from '../middleware/error.middleware.js';

export const hospitalsRouter = Router();

hospitalsRouter.post(
  '/register',
  asyncHandler(async (req, res) => {
    const { hospital_id, hospital_code, name, country, region, city } = req.body;
    if (!hospital_id || !hospital_code || !name) {
      return res.status(400).json({ success: false, error: 'hospital_id, hospital_code, and name are required' });
    }
    const hospital = await prisma.hospital.create({
      data: { hospitalId: hospital_id, hospitalCode: hospital_code, name, country, region, city }
    });
    await prisma.auditLog.create({
      data: { action: 'hospital.registered', entityType: 'hospital', entityId: hospital.hospitalId, metadata: req.body }
    });
    res.status(201).json({ success: true, hospital });
  })
);

hospitalsRouter.post(
  '/installations/activate',
  asyncHandler(async (req, res) => {
    const { hospital_id, installation_id, device_label, license_key, hmac_secret } = req.body;
    if (!hospital_id || !installation_id || !license_key || !hmac_secret) {
      return res.status(400).json({
        success: false,
        error: 'hospital_id, installation_id, license_key, and hmac_secret are required'
      });
    }
    const licenseKeyHash = await bcrypt.hash(license_key, 12);
    const hmacSecretEncrypted = encryptSecret(hmac_secret);
    const installation = await prisma.hospitalInstallation.create({
      data: {
        hospitalId: hospital_id,
        installationId: installation_id,
        deviceLabel: device_label,
        licenseKeyHash,
        hmacSecretEncrypted
      }
    });
    await prisma.auditLog.create({
      data: { action: 'installation.activated', entityType: 'installation', entityId: installation.installationId }
    });
    // Note: hmac_secret is never echoed back — the offline HMS already has its
    // own copy locally; it only ever needs to sign requests with it, not
    // resend it.
    res.status(201).json({
      success: true,
      installation_id: installation.installationId,
      status: installation.status
    });
  })
);

// Public — for the patient web portal and WhatsApp agent to browse
// hospitals and see a hospital's roster/services before booking an
// in-person appointment.
hospitalsRouter.get(
  '/',
  asyncHandler(async (req, res) => {
    const { city } = req.query;
    const hospitals = await prisma.hospital.findMany({
      where: { status: 'active', ...(city ? { city: String(city) } : {}) },
      take: 50
    });
    res.json({ success: true, hospitals });
  })
);

// Public — proximity search by real GPS coordinates, for "hospitals near
// me" from the web portal's geolocation button or a WhatsApp shared
// location. Plain Haversine distance in raw SQL — no PostGIS extension
// needed for a search radius this small (a handful of hospitals per
// city, not a global-scale geo index).
hospitalsRouter.get(
  '/nearby',
  asyncHandler(async (req, res) => {
    const lat = Number(req.query.lat);
    const lng = Number(req.query.lng);
    const radiusKm = Math.min(Number(req.query.radius_km ?? 25), 200);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
      return res.status(400).json({ success: false, error: 'lat and lng query params are required and must be numbers' });
    }
    const nearby = await findHospitalsNear(lat, lng, radiusKm);
    res.json({ success: true, radius_km: radiusKm, hospitals: nearby });
  })
);

// Registered after /nearby deliberately — a literal path must come before
// a parameterized one on the same router, or Express matches the
// parameterized one first (treating "nearby" as if it were a real
// hospitalId). Same lesson learned the hard way earlier this project.
hospitalsRouter.get(
  '/:hospitalId',
  asyncHandler(async (req, res) => {
    const hospital = await prisma.hospital.findUnique({ where: { hospitalId: req.params.hospitalId } });
    if (!hospital) return res.status(404).json({ success: false, error: 'hospital_not_found' });
    res.json({ success: true, hospital });
  })
);

hospitalsRouter.get(
  '/:hospitalId/doctors',
  asyncHandler(async (req, res) => {
    const roster = await prisma.hospitalDoctorRoster.findMany({
      where: { hospitalId: req.params.hospitalId },
      include: { workingHours: { orderBy: { dayOfWeek: 'asc' } } }
    });
    res.json({ success: true, doctors: roster });
  })
);

hospitalsRouter.get(
  '/:hospitalId/doctors/:rosterId/slots',
  asyncHandler(async (req, res) => {
    const days = Math.min(Number(req.query.days ?? 7), 14);
    try {
      const slots = await getHospitalRosterSlotsForNextDays(req.params.rosterId, days);
      res.json({ success: true, slots });
    } catch {
      res.status(404).json({ success: false, error: 'roster_doctor_not_found' });
    }
  })
);

hospitalsRouter.get(
  '/:hospitalId/services',
  asyncHandler(async (req, res) => {
    const services = await prisma.hospitalService.findMany({ where: { hospitalId: req.params.hospitalId } });
    res.json({ success: true, services });
  })
);
